#warna termux
birutua = "\033[0;34m"
putih = "\033[0m"
kuning = "\033[1;33m"
hijau = "\033[1;32m"
merah = "\033[1;31m"
biru = "\033[0;36m"
ungu = "\033[1;35m"
