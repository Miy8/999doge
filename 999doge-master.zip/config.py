'''
Layscape Kumaru Script
My Principal Anyone Can Enjoy Premium Feature Without Buy It ^.^

Any Suggest PM Me On Whatsapp or Telegram
'''


'''
Fill Your 999Doge Account
'''
account = {
	"Username":"BdLand",
	"Password":"nozomi1986"
}
'''
Change Your Bet Strategy/Bet Setting
'''
betset = {
	"Basebet":"0.001",
	"Chance1":"80",
	"Chance2":"85"
}

'''
Select Bet Setting Tools
Note :
IFLose = Increase Bet After Lose
IFWin = Increase Bet After Win
'''
tools = {
	"IFLose":"2",
	"IFWin":"3",
	"TargetProfit":"100",
	"TargetLose":"99999999999",
	"ResetBetIfWin":"1.5",
	"ResetBetIfLose":"4",
	"ResetSeedEachBet":"ON"
}

'''
Select Premium Feature ^.^
Note :
Interval In Second, Comma Allowed
RefreshIfWin and RefreshIfLose Use Number to Use
Example 
RefreshIfWin : 3. Automaticaly Refresh After 3 Win Streak OFF to OFF
RefreshIfLose : 3. Automaticaly Refresh After 3 Lose Streak OFF to OFF
'''
feature = {
	"BetInterval":"0",
	"BetIntervalLose":"0",
	"BetInvervalWin":"0",
	"IntervalRefresh":"0",
	"RefreshIfWin":"OFF",
	"RefreshIfLose":"OFF",
	"AutoRefresh":"ON"
}

'''
Dont Forget To Change Your Wallet Here
'''
withdraw = {
	"AutoWithdraw":"ON",
	"AmountWithdraw":"5",
	"WithdrawIfBalance":"5",
	"Address":"D916W29eCE6zvryu8wGUs7XYHiqhjmrEyd"
}
